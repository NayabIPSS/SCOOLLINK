const express = require("express")
const admin = require("firebase-admin")
const tf = require("@tensorflow/tfjs-node")

const app = express()
app.use(express.json())

const db = admin.firestore()

// Predict student performance trends
app.post("/performance-prediction/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params

    // Gather historical data
    const [attendanceData, gradesData, wellnessData] = await Promise.all([
      getAttendanceHistory(studentId),
      getGradesHistory(studentId),
      getWellnessHistory(studentId),
    ])

    // Simple prediction algorithm (in production, use trained ML models)
    const prediction = await predictPerformance({
      attendance: attendanceData,
      grades: gradesData,
      wellness: wellnessData,
    })

    // Generate recommendations
    const recommendations = generateRecommendations(prediction)

    // Save prediction
    await db.collection("predictions").add({
      studentId,
      type: "performance",
      prediction,
      recommendations,
      confidence: prediction.confidence,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
    })

    res.json({
      prediction,
      recommendations,
      generatedAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Performance prediction error:", error)
    res.status(500).json({ error: "Prediction service unavailable" })
  }
})

// Predict wellness trends
app.post("/wellness-prediction/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params

    // Get wellness history
    const wellnessHistory = await getWellnessHistory(studentId)
    const moodHistory = await getMoodHistory(studentId)
    const activityHistory = await getActivityHistory(studentId)

    // Analyze patterns
    const analysis = analyzeWellnessPatterns({
      wellness: wellnessHistory,
      moods: moodHistory,
      activities: activityHistory,
    })

    // Generate wellness recommendations
    const recommendations = generateWellnessRecommendations(analysis)

    // Identify risk factors
    const riskFactors = identifyRiskFactors(analysis)

    res.json({
      analysis,
      recommendations,
      riskFactors,
      generatedAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Wellness prediction error:", error)
    res.status(500).json({ error: "Wellness prediction unavailable" })
  }
})

// Predict optimal study schedule
app.post("/study-schedule/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params

    // Get student's performance patterns
    const performanceData = await getPerformancePatterns(studentId)
    const schedulePreferences = await getSchedulePreferences(studentId)

    // Generate optimized schedule
    const optimizedSchedule = generateOptimalSchedule({
      performance: performanceData,
      preferences: schedulePreferences,
    })

    res.json({
      schedule: optimizedSchedule,
      reasoning: optimizedSchedule.reasoning,
      generatedAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Schedule optimization error:", error)
    res.status(500).json({ error: "Schedule optimization unavailable" })
  }
})

// Helper functions
async function getAttendanceHistory(studentId) {
  const snapshot = await db
    .collection("attendance")
    .where("studentId", "==", studentId)
    .orderBy("date", "desc")
    .limit(30)
    .get()

  return snapshot.docs.map((doc) => doc.data())
}

async function getGradesHistory(studentId) {
  const snapshot = await db
    .collection("grades")
    .where("studentId", "==", studentId)
    .orderBy("date", "desc")
    .limit(20)
    .get()

  return snapshot.docs.map((doc) => doc.data())
}

async function getWellnessHistory(studentId) {
  const snapshot = await db
    .collection("wellnessMetrics")
    .doc(studentId)
    .collection("history")
    .orderBy("date", "desc")
    .limit(30)
    .get()

  return snapshot.docs.map((doc) => doc.data())
}

async function getMoodHistory(studentId) {
  const snapshot = await db
    .collection("moodEntries")
    .where("studentId", "==", studentId)
    .orderBy("date", "desc")
    .limit(14)
    .get()

  return snapshot.docs.map((doc) => doc.data())
}

async function getActivityHistory(studentId) {
  const snapshot = await db
    .collection("wellnessActivities")
    .where("studentId", "==", studentId)
    .orderBy("date", "desc")
    .limit(20)
    .get()

  return snapshot.docs.map((doc) => doc.data())
}

async function getPerformancePatterns(studentId) {
  // Placeholder for actual implementation
  return []
}

async function getSchedulePreferences(studentId) {
  // Placeholder for actual implementation
  return []
}

function generateOptimalSchedule(data) {
  // Placeholder for actual implementation
  return { schedule: [], reasoning: "Not implemented" }
}

// Simplified prediction algorithm
async function predictPerformance(data) {
  const { attendance, grades, wellness } = data

  // Calculate trends
  const attendanceRate = attendance.filter((a) => a.status === "present").length / attendance.length
  const averageGrade = grades.reduce((sum, g) => sum + g.score, 0) / grades.length
  const wellnessScore = wellness.length > 0 ? wellness[0].overall.score : 75

  // Simple weighted prediction
  const performanceScore = attendanceRate * 0.3 + averageGrade * 0.5 + wellnessScore * 0.2

  let trend = "stable"
  if (performanceScore > 80) trend = "improving"
  else if (performanceScore < 60) trend = "declining"

  return {
    currentScore: Math.round(performanceScore),
    trend,
    confidence: 0.75,
    factors: {
      attendance: attendanceRate,
      academic: averageGrade,
      wellness: wellnessScore,
    },
  }
}

function generateRecommendations(prediction) {
  const recommendations = []

  if (prediction.factors.attendance < 0.9) {
    recommendations.push({
      category: "attendance",
      priority: "high",
      message: "Focus on improving attendance - it significantly impacts performance",
      actions: ["Set consistent morning routine", "Address any attendance barriers"],
    })
  }

  if (prediction.factors.wellness < 70) {
    recommendations.push({
      category: "wellness",
      priority: "medium",
      message: "Consider wellness support to improve overall performance",
      actions: ["Schedule counselor meeting", "Implement stress management techniques"],
    })
  }

  if (prediction.factors.academic < 75) {
    recommendations.push({
      category: "academic",
      priority: "high",
      message: "Additional academic support recommended",
      actions: ["Extra tutoring sessions", "Study schedule optimization"],
    })
  }

  return recommendations
}

function analyzeWellnessPatterns(data) {
  const { wellness, moods, activities } = data

  // Analyze mood patterns
  const moodCounts = moods.reduce((acc, mood) => {
    acc[mood.mood] = (acc[mood.mood] || 0) + 1
    return acc
  }, {})

  // Analyze activity impacts
  const positiveActivities = activities.filter((a) => a.impact === "positive").length
  const concernActivities = activities.filter((a) => a.impact === "concern").length

  return {
    moodDistribution: moodCounts,
    activityBalance: {
      positive: positiveActivities,
      concerns: concernActivities,
      ratio: positiveActivities / (concernActivities || 1),
    },
    overallTrend:
      wellness.length > 1
        ? wellness[0].overall.score > wellness[1].overall.score
          ? "improving"
          : "declining"
        : "stable",
  }
}

function generateWellnessRecommendations(analysis) {
  const recommendations = []

  if (analysis.moodDistribution.sad > analysis.moodDistribution.happy) {
    recommendations.push({
      category: "emotional",
      message: "Consider additional emotional support",
      priority: "high",
    })
  }

  if (analysis.activityBalance.ratio < 2) {
    recommendations.push({
      category: "activities",
      message: "Increase positive activities and address concerns",
      priority: "medium",
    })
  }

  return recommendations
}

function identifyRiskFactors(analysis) {
  const risks = []

  if (analysis.moodDistribution.sad > 3) {
    risks.push({
      factor: "Frequent negative moods",
      severity: "medium",
      recommendation: "Consider counseling support",
    })
  }

  return risks
}

const PORT = process.env.PORT || 4002
app.listen(PORT, () => {
  console.log(`AI Prediction Service running on port ${PORT}`)
})
