const express = require("express")
const { Configuration, OpenAIApi } = require("openai")
const admin = require("firebase-admin")

const app = express()
app.use(express.json())

const db = admin.firestore()

// Initialize OpenAI
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})
const openai = new OpenAIApi(configuration)

// AI Chat endpoint for parents
app.post("/parent-assistant", async (req, res) => {
  try {
    const { message, studentId, context } = req.body
    const parentId = req.user.id

    // Get student context for personalized responses
    const studentDoc = await db.collection("students").doc(studentId).get()
    const studentData = studentDoc.exists ? studentDoc.data() : null

    // Get recent wellness data for context
    const wellnessDoc = await db.collection("wellnessMetrics").doc(studentId).get()
    const wellnessData = wellnessDoc.exists ? wellnessDoc.data() : null

    // Build context for AI
    const systemPrompt = `You are a helpful AI assistant for Scoollink, a school management app. 
    You're helping a parent with questions about their child's school life.
    
    Student Information:
    - Name: ${studentData?.name || "Student"}
    - Class: ${studentData?.class || "Unknown"}
    - Current Wellness Score: ${wellnessData?.overall?.score || "Not available"}%
    
    You can help with:
    - School policies and procedures
    - Understanding wellness reports
    - Homework and academic guidance
    - Communication with teachers
    - School events and activities
    
    Be supportive, informative, and always prioritize the child's wellbeing.
    If asked about medical or serious behavioral concerns, recommend speaking with school counselors or healthcare professionals.`

    const completion = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message },
      ],
      max_tokens: 500,
      temperature: 0.7,
    })

    const aiResponse = completion.data.choices[0].message.content

    // Save chat history
    await db.collection("chatHistory").add({
      parentId,
      studentId,
      userMessage: message,
      aiResponse,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      context: context || "general",
    })

    res.json({
      response: aiResponse,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("AI Chat error:", error)
    res.status(500).json({
      error: "AI service temporarily unavailable",
      fallbackResponse:
        "I apologize, but I'm having trouble responding right now. Please try again later or contact the school directly for assistance.",
    })
  }
})

// AI Homework Help for students
app.post("/homework-help", async (req, res) => {
  try {
    const { question, subject, gradeLevel, studentId } = req.body

    const systemPrompt = `You are an educational AI tutor helping a grade ${gradeLevel} student with ${subject}.
    
    Guidelines:
    - Provide hints and guidance rather than direct answers
    - Use age-appropriate language and examples
    - Encourage critical thinking
    - If the question is too advanced or inappropriate, suggest asking a teacher
    - Keep responses concise and engaging
    - Focus on learning process, not just the answer`

    const completion = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: question },
      ],
      max_tokens: 400,
      temperature: 0.6,
    })

    const aiResponse = completion.data.choices[0].message.content

    // Log homework help session
    await db.collection("homeworkHelp").add({
      studentId,
      subject,
      question,
      aiResponse,
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
    })

    res.json({
      response: aiResponse,
      subject,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Homework help error:", error)
    res.status(500).json({
      error: "Homework help temporarily unavailable",
      fallbackResponse: "I'm having trouble right now. Please ask your teacher or parent for help with this question.",
    })
  }
})

// Get chat history
app.get("/history/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { limit = 20 } = req.query

    const chatSnapshot = await db
      .collection("chatHistory")
      .where("studentId", "==", studentId)
      .where("parentId", "==", req.user.id)
      .orderBy("timestamp", "desc")
      .limit(Number.parseInt(limit))
      .get()

    const chatHistory = chatSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    res.json({ chatHistory })
  } catch (error) {
    console.error("Chat history error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

const PORT = process.env.PORT || 4001
app.listen(PORT, () => {
  console.log(`AI Chat Service running on port ${PORT}`)
})
