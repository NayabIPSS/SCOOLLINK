const express = require("express")
const admin = require("firebase-admin")

const app = express()
app.use(express.json())

const db = admin.firestore()

// Get wellness dashboard
app.get("/dashboard/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params

    // Get current wellness metrics
    const wellnessDoc = await db.collection("wellnessMetrics").doc(studentId).get()

    let wellnessData = {
      emotional: { score: 0, trend: "stable" },
      social: { score: 0, trend: "stable" },
      academic: { score: 0, trend: "stable" },
      physical: { score: 0, trend: "stable" },
      overall: { score: 0, trend: "stable" },
    }

    if (wellnessDoc.exists) {
      wellnessData = { ...wellnessData, ...wellnessDoc.data() }
    }

    // Get recent mood entries
    const moodSnapshot = await db
      .collection("moodEntries")
      .where("studentId", "==", studentId)
      .orderBy("date", "desc")
      .limit(7)
      .get()

    const moodHistory = moodSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Get recent activities
    const activitiesSnapshot = await db
      .collection("wellnessActivities")
      .where("studentId", "==", studentId)
      .orderBy("date", "desc")
      .limit(10)
      .get()

    const activities = activitiesSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Get achievements
    const achievementsSnapshot = await db
      .collection("achievements")
      .where("studentId", "==", studentId)
      .where("dateEarned", ">=", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
      .orderBy("dateEarned", "desc")
      .get()

    const achievements = achievementsSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Get counselor notes
    const counselorNotesSnapshot = await db
      .collection("counselorNotes")
      .where("studentId", "==", studentId)
      .orderBy("date", "desc")
      .limit(5)
      .get()

    const counselorNotes = counselorNotesSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    res.json({
      wellnessMetrics: wellnessData,
      moodHistory,
      activities,
      achievements,
      counselorNotes,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Wellness dashboard error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Record mood entry
app.post("/mood/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { mood, notes, triggers } = req.body

    const moodEntry = {
      studentId,
      mood,
      notes: notes || "",
      triggers: triggers || [],
      date: new Date().toISOString().split("T")[0],
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      recordedBy: req.user.id,
    }

    const docRef = await db.collection("moodEntries").add(moodEntry)

    // Update wellness metrics based on mood
    await updateWellnessMetrics(studentId, "emotional", mood)

    res.json({
      id: docRef.id,
      ...moodEntry,
      message: "Mood entry recorded successfully",
    })
  } catch (error) {
    console.error("Mood entry error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Record wellness activity
app.post("/activity/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { type, description, impact, category } = req.body

    const activity = {
      studentId,
      type,
      description,
      impact, // positive, neutral, concern
      category, // social, academic, emotional, physical
      date: new Date().toISOString().split("T")[0],
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      recordedBy: req.user.id,
    }

    const docRef = await db.collection("wellnessActivities").add(activity)

    // Update wellness metrics based on activity
    await updateWellnessMetrics(studentId, category, impact)

    res.json({
      id: docRef.id,
      ...activity,
      message: "Activity recorded successfully",
    })
  } catch (error) {
    console.error("Activity recording error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Add counselor note
app.post("/counselor-note/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { note, priority, recommendations, followUpDate } = req.body

    const counselorNote = {
      studentId,
      counselorId: req.user.id,
      note,
      priority: priority || "medium",
      recommendations: recommendations || [],
      followUpDate: followUpDate || null,
      date: new Date().toISOString().split("T")[0],
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
    }

    const docRef = await db.collection("counselorNotes").add(counselorNote)

    // Notify parents if high priority
    if (priority === "high") {
      const studentDoc = await db.collection("students").doc(studentId).get()
      if (studentDoc.exists) {
        const student = studentDoc.data()
        const notifications = student.parentIds?.map((parentId) => ({
          parentId,
          studentId,
          type: "counselor_note",
          title: "Important Update from School Counselor",
          message: `New counselor note for ${student.name}`,
          priority: "high",
          timestamp: admin.firestore.FieldValue.serverTimestamp(),
        }))

        if (notifications?.length > 0) {
          const batch = db.batch()
          notifications.forEach((notification) => {
            const notificationRef = db.collection("notifications").doc()
            batch.set(notificationRef, notification)
          })
          await batch.commit()
        }
      }
    }

    res.json({
      id: docRef.id,
      ...counselorNote,
      message: "Counselor note added successfully",
    })
  } catch (error) {
    console.error("Counselor note error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Award achievement
app.post("/achievement/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { title, description, category, icon, color } = req.body

    const achievement = {
      studentId,
      title,
      description,
      category,
      icon: icon || "award",
      color: color || "blue",
      dateEarned: admin.firestore.FieldValue.serverTimestamp(),
      awardedBy: req.user.id,
    }

    const docRef = await db.collection("achievements").add(achievement)

    // Update wellness metrics positively
    await updateWellnessMetrics(studentId, category, "positive")

    res.json({
      id: docRef.id,
      ...achievement,
      message: "Achievement awarded successfully",
    })
  } catch (error) {
    console.error("Achievement error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Helper function to update wellness metrics
async function updateWellnessMetrics(studentId, category, impact) {
  try {
    const wellnessRef = db.collection("wellnessMetrics").doc(studentId)
    const wellnessDoc = await wellnessRef.get()

    let currentMetrics = {
      emotional: { score: 50, trend: "stable" },
      social: { score: 50, trend: "stable" },
      academic: { score: 50, trend: "stable" },
      physical: { score: 50, trend: "stable" },
      overall: { score: 50, trend: "stable" },
    }

    if (wellnessDoc.exists) {
      currentMetrics = { ...currentMetrics, ...wellnessDoc.data() }
    }

    // Calculate score adjustment based on impact
    let adjustment = 0
    if (impact === "positive" || impact === "happy") adjustment = 2
    else if (impact === "concern" || impact === "sad") adjustment = -1
    else if (impact === "neutral") adjustment = 0

    // Update specific category
    if (currentMetrics[category]) {
      currentMetrics[category].score = Math.max(0, Math.min(100, currentMetrics[category].score + adjustment))
    }

    // Calculate overall score
    const categories = ["emotional", "social", "academic", "physical"]
    const totalScore = categories.reduce((sum, cat) => sum + (currentMetrics[cat]?.score || 50), 0)
    currentMetrics.overall.score = Math.round(totalScore / categories.length)

    // Update trends (simplified)
    Object.keys(currentMetrics).forEach((key) => {
      if (adjustment > 0) currentMetrics[key].trend = "up"
      else if (adjustment < 0) currentMetrics[key].trend = "down"
      else currentMetrics[key].trend = "stable"
    })

    currentMetrics.lastUpdated = admin.firestore.FieldValue.serverTimestamp()

    await wellnessRef.set(currentMetrics, { merge: true })
  } catch (error) {
    console.error("Wellness metrics update error:", error)
  }
}

const PORT = process.env.PORT || 3006
app.listen(PORT, () => {
  console.log(`Wellness Service running on port ${PORT}`)
})
