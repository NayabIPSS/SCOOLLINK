const express = require("express")
const admin = require("firebase-admin")

const app = express()
app.use(express.json())

const db = admin.firestore()

// Get live bus tracking data
app.get("/bus/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params

    // Get student's bus assignment
    const studentDoc = await db.collection("students").doc(studentId).get()
    if (!studentDoc.exists) {
      return res.status(404).json({ error: "Student not found" })
    }

    const busId = studentDoc.data().busId
    if (!busId) {
      return res.status(404).json({ error: "No bus assigned to student" })
    }

    // Get current bus location and status
    const busDoc = await db.collection("buses").doc(busId).get()
    if (!busDoc.exists) {
      return res.status(404).json({ error: "Bus not found" })
    }

    const busData = busDoc.data()

    // Get driver information
    const driverDoc = await db.collection("drivers").doc(busData.driverId).get()
    const driverData = driverDoc.exists ? driverDoc.data() : null

    // Get student's pickup/dropoff locations
    const routeDoc = await db.collection("routes").doc(busData.routeId).get()
    const routeData = routeDoc.exists ? routeDoc.data() : null

    // Calculate ETA (simplified calculation)
    const studentStop = routeData?.stops?.find((stop) => stop.studentIds?.includes(studentId))

    let estimatedArrival = null
    if (studentStop && busData.currentLocation) {
      // Simplified ETA calculation - in real implementation, use Google Maps API
      const distance = calculateDistance(busData.currentLocation, studentStop.location)
      const avgSpeed = 30 // km/h
      const etaMinutes = Math.round((distance / avgSpeed) * 60)
      estimatedArrival = etaMinutes
    }

    // Get today's journey history
    const today = new Date().toISOString().split("T")[0]
    const journeySnapshot = await db
      .collection("journeyLogs")
      .where("studentId", "==", studentId)
      .where("date", "==", today)
      .orderBy("timestamp", "desc")
      .get()

    const journeyHistory = journeySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    res.json({
      bus: {
        id: busId,
        number: busData.number,
        currentLocation: busData.currentLocation,
        status: busData.status,
        lastUpdated: busData.lastUpdated,
      },
      driver: driverData
        ? {
            name: driverData.name,
            phone: driverData.phone,
            license: driverData.license,
            experience: driverData.experience,
          }
        : null,
      route: {
        id: busData.routeId,
        name: routeData?.name,
        studentStop: studentStop,
      },
      estimatedArrival,
      journeyHistory,
    })
  } catch (error) {
    console.error("Bus tracking error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Get RFID scan history
app.get("/rfid/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { limit = 10 } = req.query

    const rfidSnapshot = await db
      .collection("rfidScans")
      .where("studentId", "==", studentId)
      .orderBy("timestamp", "desc")
      .limit(Number.parseInt(limit))
      .get()

    const rfidHistory = rfidSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    res.json({ rfidHistory })
  } catch (error) {
    console.error("RFID history error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Update bus location (for bus drivers/GPS devices)
app.post("/bus/:busId/location", async (req, res) => {
  try {
    const { busId } = req.params
    const { latitude, longitude, speed, heading } = req.body

    await db.collection("buses").doc(busId).update({
      currentLocation: {
        latitude,
        longitude,
        speed,
        heading,
      },
      lastUpdated: admin.firestore.FieldValue.serverTimestamp(),
    })

    // Notify parents of students on this bus
    const studentsSnapshot = await db.collection("students").where("busId", "==", busId).get()

    const notifications = []
    studentsSnapshot.docs.forEach((doc) => {
      const student = doc.data()
      student.parentIds?.forEach((parentId) => {
        notifications.push({
          parentId,
          studentId: doc.id,
          type: "bus_location_update",
          title: "Bus Location Updated",
          message: `Bus ${busId} location updated`,
          data: { latitude, longitude, busId },
          timestamp: admin.firestore.FieldValue.serverTimestamp(),
        })
      })
    })

    // Send notifications (implement push notification service)
    if (notifications.length > 0) {
      await db.collection("notifications").add(...notifications)
    }

    res.json({ message: "Location updated successfully" })
  } catch (error) {
    console.error("Location update error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Helper function to calculate distance between two points
function calculateDistance(point1, point2) {
  const R = 6371 // Earth's radius in km
  const dLat = ((point2.latitude - point1.latitude) * Math.PI) / 180
  const dLon = ((point2.longitude - point1.longitude) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((point1.latitude * Math.PI) / 180) *
      Math.cos((point2.latitude * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

const PORT = process.env.PORT || 3003
app.listen(PORT, () => {
  console.log(`Tracking Service running on port ${PORT}`)
})
