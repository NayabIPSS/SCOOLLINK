const express = require("express")
const admin = require("firebase-admin")

const app = express()
app.use(express.json())

// Initialize Firebase Admin
admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: process.env.FIREBASE_DATABASE_URL,
})

const db = admin.firestore()

// Get student dashboard data
app.get("/dashboard/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const parentId = req.user.id

    // Verify parent has access to this student
    const studentDoc = await db.collection("students").doc(studentId).get()
    if (!studentDoc.exists || !studentDoc.data().parentIds.includes(parentId)) {
      return res.status(403).json({ error: "Access denied" })
    }

    const student = studentDoc.data()

    // Get today's schedule
    const today = new Date().toISOString().split("T")[0]
    const scheduleSnapshot = await db
      .collection("schedules")
      .where("studentId", "==", studentId)
      .where("date", "==", today)
      .get()

    const schedule = scheduleSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Get recent attendance
    const attendanceSnapshot = await db
      .collection("attendance")
      .where("studentId", "==", studentId)
      .orderBy("date", "desc")
      .limit(5)
      .get()

    const attendance = attendanceSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Get pending homework
    const homeworkSnapshot = await db
      .collection("homework")
      .where("studentId", "==", studentId)
      .where("status", "==", "pending")
      .orderBy("dueDate", "asc")
      .get()

    const homework = homeworkSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Get recent announcements
    const announcementsSnapshot = await db
      .collection("announcements")
      .where("classId", "==", student.classId)
      .orderBy("createdAt", "desc")
      .limit(3)
      .get()

    const announcements = announcementsSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    res.json({
      student: {
        id: studentId,
        name: student.name,
        class: student.class,
        profileImage: student.profileImage,
      },
      schedule,
      attendance,
      homework,
      announcements,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Dashboard error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Get attendance records
app.get("/attendance/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { month, year } = req.query

    const startDate = new Date(year, month - 1, 1)
    const endDate = new Date(year, month, 0)

    const attendanceSnapshot = await db
      .collection("attendance")
      .where("studentId", "==", studentId)
      .where("date", ">=", startDate.toISOString().split("T")[0])
      .where("date", "<=", endDate.toISOString().split("T")[0])
      .orderBy("date", "desc")
      .get()

    const attendance = attendanceSnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Calculate statistics
    const totalDays = attendance.length
    const presentDays = attendance.filter((a) => a.status === "present").length
    const lateDays = attendance.filter((a) => a.status === "late").length
    const absentDays = attendance.filter((a) => a.status === "absent").length

    res.json({
      attendance,
      statistics: {
        totalDays,
        presentDays,
        lateDays,
        absentDays,
        attendancePercentage: totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 0,
      },
    })
  } catch (error) {
    console.error("Attendance error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Apply for leave
app.post("/leave/:studentId", async (req, res) => {
  try {
    const { studentId } = req.params
    const { startDate, endDate, reason, type } = req.body

    const leaveApplication = {
      studentId,
      parentId: req.user.id,
      startDate,
      endDate,
      reason,
      type,
      status: "pending",
      appliedAt: admin.firestore.FieldValue.serverTimestamp(),
      approvedBy: null,
      approvedAt: null,
    }

    const docRef = await db.collection("leaveApplications").add(leaveApplication)

    res.json({
      id: docRef.id,
      ...leaveApplication,
      message: "Leave application submitted successfully",
    })
  } catch (error) {
    console.error("Leave application error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

const PORT = process.env.PORT || 3002
app.listen(PORT, () => {
  console.log(`Student Service running on port ${PORT}`)
})
