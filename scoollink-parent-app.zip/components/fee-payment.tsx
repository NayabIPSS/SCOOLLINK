"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { CreditCard, Download, Calendar, AlertCircle, CheckCircle, DollarSign, Receipt, Bell } from "lucide-react"

export function FeePayment() {
  const feeBreakdown = [
    { category: "Tuition Fee", amount: 1200, status: "paid", dueDate: "2024-01-01" },
    { category: "Transportation", amount: 150, status: "paid", dueDate: "2024-01-01" },
    { category: "Activity Fee", amount: 100, status: "pending", dueDate: "2024-01-15" },
    { category: "Library Fee", amount: 50, status: "pending", dueDate: "2024-01-15" },
    { category: "Lab Fee", amount: 75, status: "overdue", dueDate: "2024-01-10" },
  ]

  const totalFees = feeBreakdown.reduce((sum, fee) => sum + fee.amount, 0)
  const paidFees = feeBreakdown.filter((fee) => fee.status === "paid").reduce((sum, fee) => sum + fee.amount, 0)
  const paymentProgress = (paidFees / totalFees) * 100

  return (
    <div className="space-y-4 pb-20">
      {/* Payment Overview */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Fee Overview</h2>
              <p className="text-gray-600">Academic Year 2023-24</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-600">${paidFees}</div>
              <p className="text-sm text-gray-600">of ${totalFees} paid</p>
            </div>
          </div>

          <Progress value={paymentProgress} className="h-3 mb-3" />

          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">{Math.round(paymentProgress)}% Complete</span>
            <span className="text-gray-600">${totalFees - paidFees} remaining</span>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button className="h-16 flex-col space-y-1 bg-blue-600 hover:bg-blue-700">
          <CreditCard className="w-5 h-5" />
          <span className="text-sm">Pay Now</span>
        </Button>
        <Button variant="outline" className="h-16 flex-col space-y-1">
          <Download className="w-5 h-5" />
          <span className="text-sm">Download Receipt</span>
        </Button>
      </div>

      {/* Fee Breakdown */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <DollarSign className="w-5 h-5 mr-2 text-green-600" />
            Fee Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {feeBreakdown.map((fee, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                {fee.status === "paid" && <CheckCircle className="w-5 h-5 text-green-600" />}
                {fee.status === "pending" && <Calendar className="w-5 h-5 text-yellow-600" />}
                {fee.status === "overdue" && <AlertCircle className="w-5 h-5 text-red-600" />}

                <div>
                  <p className="font-medium">{fee.category}</p>
                  <p className="text-sm text-gray-600">Due: {new Date(fee.dueDate).toLocaleDateString()}</p>
                </div>
              </div>

              <div className="text-right">
                <p className="font-semibold">${fee.amount}</p>
                <Badge
                  variant={fee.status === "paid" ? "default" : fee.status === "overdue" ? "destructive" : "secondary"}
                  className={fee.status === "paid" ? "bg-green-500" : fee.status === "pending" ? "bg-yellow-500" : ""}
                >
                  {fee.status.charAt(0).toUpperCase() + fee.status.slice(1)}
                </Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Payment Methods */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <CreditCard className="w-5 h-5 mr-2 text-purple-600" />
            Payment Methods
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="h-16 flex-col space-y-1">
              <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                <span className="text-white text-xs font-bold">UPI</span>
              </div>
              <span className="text-sm">UPI Payment</span>
            </Button>

            <Button variant="outline" className="h-16 flex-col space-y-1">
              <CreditCard className="w-5 h-5" />
              <span className="text-sm">Credit/Debit</span>
            </Button>

            <Button variant="outline" className="h-16 flex-col space-y-1">
              <div className="w-8 h-8 bg-green-600 rounded flex items-center justify-center">
                <span className="text-white text-xs font-bold">NB</span>
              </div>
              <span className="text-sm">Net Banking</span>
            </Button>

            <Button variant="outline" className="h-16 flex-col space-y-1">
              <div className="w-8 h-8 bg-purple-600 rounded flex items-center justify-center">
                <span className="text-white text-xs font-bold">W</span>
              </div>
              <span className="text-sm">Wallet</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Payment History */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Receipt className="w-5 h-5 mr-2 text-indigo-600" />
            Recent Payments
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-green-800">Tuition Fee</p>
                <p className="text-sm text-green-600">Jan 1, 2024 • UPI Payment</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold text-green-800">$1,200</p>
              <Button size="sm" variant="outline" className="mt-1">
                <Download className="w-3 h-3 mr-1" />
                Receipt
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-green-800">Transportation</p>
                <p className="text-sm text-green-600">Jan 1, 2024 • Credit Card</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold text-green-800">$150</p>
              <Button size="sm" variant="outline" className="mt-1">
                <Download className="w-3 h-3 mr-1" />
                Receipt
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Auto-Pay Settings */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Bell className="w-5 h-5 mr-2 text-orange-600" />
            Payment Reminders
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div>
                <p className="font-medium text-blue-800">Auto-Pay Setup</p>
                <p className="text-sm text-blue-600">Never miss a payment deadline</p>
              </div>
              <Button size="sm" variant="outline">
                Setup
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <div>
                <p className="font-medium text-yellow-800">Payment Reminders</p>
                <p className="text-sm text-yellow-600">Get notified 3 days before due date</p>
              </div>
              <Button size="sm" variant="outline">
                Enable
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Outstanding Balance Alert */}
      {feeBreakdown.some((fee) => fee.status === "overdue") && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <AlertCircle className="w-6 h-6 text-red-600" />
              <div className="flex-1">
                <h3 className="font-semibold text-red-800">Overdue Payment</h3>
                <p className="text-sm text-red-600">You have overdue fees. Please pay to avoid late charges.</p>
              </div>
              <Button className="bg-red-600 hover:bg-red-700">Pay Now</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
