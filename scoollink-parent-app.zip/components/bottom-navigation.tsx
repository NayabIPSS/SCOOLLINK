"use client"

import { Home, MapPin, Calendar, MessageCircle, ShoppingBag, Heart } from "lucide-react"
import { cn } from "@/lib/utils"

interface BottomNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: "home", label: "Home", icon: Home },
    { id: "tracking", label: "Track", icon: MapPin },
    { id: "schedule", label: "Schedule", icon: Calendar },
    { id: "chat", label: "Chat", icon: MessageCircle },
    { id: "shopping", label: "Shop", icon: ShoppingBag },
    { id: "wellness", label: "Wellness", icon: Heart },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 safe-area-pb">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={cn(
                "flex flex-col items-center py-2 px-3 rounded-lg transition-colors",
                activeTab === tab.id ? "text-blue-600 bg-blue-50" : "text-gray-500 hover:text-gray-700",
              )}
            >
              <Icon className="w-5 h-5 mb-1" />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
