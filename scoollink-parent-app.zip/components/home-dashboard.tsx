"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, MapPin, BookOpen, AlertCircle, CheckCircle, Calendar, MessageSquare, CreditCard } from "lucide-react"

export function HomeDashboard() {
  return (
    <div className="space-y-4 pb-20">
      {/* Welcome Section */}
      <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">Good Morning, Sarah!</h2>
              <p className="text-blue-100">Emma is having a great day at school</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-blue-100">Today</p>
              <p className="text-lg font-semibold">{new Date().toLocaleDateString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Status Cards */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-3">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-green-800">Present Today</p>
                <p className="text-xs text-green-600">Checked in at 8:15 AM</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-3">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-blue-800">Bus Tracking</p>
                <p className="text-xs text-blue-600">5 mins to pickup</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Schedule */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-blue-600" />
            Today's Schedule
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-8 bg-blue-500 rounded"></div>
              <div>
                <p className="font-medium">Mathematics</p>
                <p className="text-sm text-gray-600">Room 204 • Ms. Johnson</p>
              </div>
            </div>
            <Badge variant="outline">9:00 AM</Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-8 bg-green-500 rounded"></div>
              <div>
                <p className="font-medium">Science Lab</p>
                <p className="text-sm text-gray-600">Lab 1 • Mr. Davis</p>
              </div>
            </div>
            <Badge variant="outline">10:30 AM</Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-8 bg-yellow-500 rounded"></div>
              <div>
                <p className="font-medium">Art Class</p>
                <p className="text-sm text-gray-600">Art Room • Ms. Wilson</p>
              </div>
            </div>
            <Badge className="bg-yellow-500">Current</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Homework & Tasks */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <BookOpen className="w-5 h-5 mr-2 text-purple-600" />
            Homework & Tasks
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-center space-x-3">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <div>
                <p className="font-medium">Math Assignment</p>
                <p className="text-sm text-gray-600">Due tomorrow</p>
              </div>
            </div>
            <Badge variant="destructive">Pending</Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <div>
                <p className="font-medium">Science Project</p>
                <p className="text-sm text-gray-600">Submitted yesterday</p>
              </div>
            </div>
            <Badge className="bg-green-500">Complete</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="h-16 flex-col space-y-1">
              <MessageSquare className="w-5 h-5" />
              <span className="text-sm">Message Teacher</span>
            </Button>
            <Button variant="outline" className="h-16 flex-col space-y-1">
              <CreditCard className="w-5 h-5" />
              <span className="text-sm">Pay Fees</span>
            </Button>
            <Button variant="outline" className="h-16 flex-col space-y-1">
              <Calendar className="w-5 h-5" />
              <span className="text-sm">Apply Leave</span>
            </Button>
            <Button variant="outline" className="h-16 flex-col space-y-1">
              <Clock className="w-5 h-5" />
              <span className="text-sm">View Reports</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Announcements */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Recent Announcements</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-blue-900">Parent-Teacher Meeting</p>
                <p className="text-sm text-blue-700">Scheduled for next Friday at 3:00 PM</p>
                <p className="text-xs text-blue-600 mt-1">2 hours ago</p>
              </div>
            </div>
          </div>

          <div className="p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-green-900">Sports Day Registration</p>
                <p className="text-sm text-green-700">Register your child for upcoming sports events</p>
                <p className="text-xs text-green-600 mt-1">1 day ago</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
