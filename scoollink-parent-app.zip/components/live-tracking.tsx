"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, Clock, Phone, Navigation, AlertTriangle, CheckCircle, Bus } from "lucide-react"

export function LiveTracking() {
  return (
    <div className="space-y-4 pb-20">
      {/* Bus Status Card */}
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-blue-100">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Bus className="w-6 h-6 text-blue-600" />
              <h2 className="text-lg font-bold text-blue-900">Bus #42</h2>
            </div>
            <Badge className="bg-green-500">On Route</Badge>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-blue-700">Estimated Arrival</span>
              <span className="font-semibold text-blue-900">5 minutes</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-blue-700">Current Location</span>
              <span className="font-semibold text-blue-900">Main Street</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-blue-700">Next Stop</span>
              <span className="font-semibold text-blue-900">Your Location</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Map Placeholder */}
      <Card>
        <CardContent className="p-0">
          <div className="h-64 bg-gradient-to-br from-green-100 to-blue-100 rounded-lg flex items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gray-200 opacity-20"></div>
            <div className="text-center z-10">
              <MapPin className="w-12 h-12 text-blue-600 mx-auto mb-2" />
              <p className="text-gray-600 font-medium">Live Map View</p>
              <p className="text-sm text-gray-500">Bus location updates every 30 seconds</p>
            </div>

            {/* Simulated bus icon */}
            <div className="absolute top-20 left-16 bg-yellow-400 p-2 rounded-full shadow-lg">
              <Bus className="w-4 h-4 text-yellow-800" />
            </div>

            {/* Simulated route line */}
            <div className="absolute top-24 left-20 w-32 h-1 bg-blue-400 rounded transform rotate-45"></div>
          </div>
        </CardContent>
      </Card>

      {/* Driver Information */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Phone className="w-5 h-5 mr-2 text-green-600" />
            Driver Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold">MR</span>
              </div>
              <div>
                <p className="font-medium">Mr. Robert Johnson</p>
                <p className="text-sm text-gray-600">License: DL123456789</p>
                <p className="text-sm text-gray-600">Experience: 8 years</p>
              </div>
            </div>
            <Button size="sm" className="bg-green-600 hover:bg-green-700">
              <Phone className="w-4 h-4 mr-1" />
              Call
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Today's Journey */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Navigation className="w-5 h-5 mr-2 text-purple-600" />
            Today's Journey
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg border border-green-200">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <div className="flex-1">
              <p className="font-medium text-green-800">Morning Pickup</p>
              <p className="text-sm text-green-600">Boarded at 7:45 AM</p>
            </div>
            <Badge className="bg-green-500">Complete</Badge>
          </div>

          <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <Clock className="w-5 h-5 text-blue-600" />
            <div className="flex-1">
              <p className="font-medium text-blue-800">Evening Pickup</p>
              <p className="text-sm text-blue-600">Scheduled at 3:30 PM</p>
            </div>
            <Badge variant="outline">Pending</Badge>
          </div>
        </CardContent>
      </Card>

      {/* RFID Alerts */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 text-orange-600" />
            Recent Alerts
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-green-800">RFID Scan Successful</p>
                <p className="text-sm text-green-600">Emma boarded the bus safely</p>
                <p className="text-xs text-green-500 mt-1">Today at 7:45 AM</p>
              </div>
            </div>
          </div>

          <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <p className="font-medium text-blue-800">Arrived at School</p>
                <p className="text-sm text-blue-600">Emma reached school safely</p>
                <p className="text-xs text-blue-500 mt-1">Today at 8:15 AM</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Route History */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Route History</CardTitle>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="w-full">
            View Complete Route History
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
