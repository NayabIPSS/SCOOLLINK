"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ShoppingCart,
  Search,
  Filter,
  Star,
  Plus,
  Minus,
  Package,
  Truck,
  BookOpen,
  Shirt,
  Palette,
  Calculator,
  Heart,
} from "lucide-react"

export function SchoolShopping() {
  const [cartItems, setCartItems] = useState<Record<string, number>>({})
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = [
    { id: "all", name: "All Items", icon: Package },
    { id: "books", name: "Books", icon: BookOpen },
    { id: "uniforms", name: "Uniforms", icon: Shirt },
    { id: "stationery", name: "Stationery", icon: Palette },
    { id: "electronics", name: "Electronics", icon: Calculator },
  ]

  const products = [
    {
      id: "1",
      name: "Mathematics Textbook Grade 5",
      category: "books",
      price: 25.99,
      originalPrice: 29.99,
      rating: 4.8,
      reviews: 124,
      image: "/placeholder.svg?height=120&width=120",
      inStock: true,
      recommended: true,
      description: "Official curriculum textbook for Grade 5 Mathematics",
    },
    {
      id: "2",
      name: "School Uniform Shirt (Blue)",
      category: "uniforms",
      price: 18.5,
      originalPrice: 22.0,
      rating: 4.6,
      reviews: 89,
      image: "/placeholder.svg?height=120&width=120",
      inStock: true,
      sizes: ["S", "M", "L", "XL"],
      description: "Official school uniform shirt - cotton blend",
    },
    {
      id: "3",
      name: "Art Supply Kit",
      category: "stationery",
      price: 15.75,
      rating: 4.9,
      reviews: 156,
      image: "/placeholder.svg?height=120&width=120",
      inStock: true,
      recommended: true,
      description: "Complete art kit with colors, brushes, and paper",
    },
    {
      id: "4",
      name: "Scientific Calculator",
      category: "electronics",
      price: 45.0,
      originalPrice: 55.0,
      rating: 4.7,
      reviews: 78,
      image: "/placeholder.svg?height=120&width=120",
      inStock: false,
      description: "Advanced scientific calculator for high school",
    },
    {
      id: "5",
      name: "School Backpack",
      category: "uniforms",
      price: 32.99,
      rating: 4.5,
      reviews: 203,
      image: "/placeholder.svg?height=120&width=120",
      inStock: true,
      description: "Durable school backpack with multiple compartments",
    },
    {
      id: "6",
      name: "Geometry Set",
      category: "stationery",
      price: 8.99,
      rating: 4.4,
      reviews: 67,
      image: "/placeholder.svg?height=120&width=120",
      inStock: true,
      description: "Complete geometry set with compass, protractor, rulers",
    },
  ]

  const filteredProducts =
    selectedCategory === "all" ? products : products.filter((product) => product.category === selectedCategory)

  const addToCart = (productId: string) => {
    setCartItems((prev) => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1,
    }))
  }

  const removeFromCart = (productId: string) => {
    setCartItems((prev) => {
      const newCart = { ...prev }
      if (newCart[productId] > 1) {
        newCart[productId]--
      } else {
        delete newCart[productId]
      }
      return newCart
    })
  }

  const getTotalItems = () => {
    return Object.values(cartItems).reduce((sum, count) => sum + count, 0)
  }

  const getTotalPrice = () => {
    return Object.entries(cartItems).reduce((sum, [productId, count]) => {
      const product = products.find((p) => p.id === productId)
      return sum + (product?.price || 0) * count
    }, 0)
  }

  return (
    <div className="space-y-4 pb-20">
      {/* Header with Search and Cart */}
      <div className="flex items-center space-x-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input placeholder="Search school supplies..." className="pl-10" />
        </div>
        <Button variant="outline" size="icon">
          <Filter className="w-4 h-4" />
        </Button>
        <Button variant="outline" size="icon" className="relative">
          <ShoppingCart className="w-4 h-4" />
          {getTotalItems() > 0 && (
            <Badge className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center text-xs bg-red-500">
              {getTotalItems()}
            </Badge>
          )}
        </Button>
      </div>

      {/* Shopping Cart Summary */}
      {getTotalItems() > 0 && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-blue-800">{getTotalItems()} items in cart</p>
                <p className="text-sm text-blue-600">Total: ${getTotalPrice().toFixed(2)}</p>
              </div>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <ShoppingCart className="w-4 h-4 mr-2" />
                Checkout
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recommended Items */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Star className="w-5 h-5 mr-2 text-yellow-500" />
            Recommended for Emma's Class
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {products
              .filter((p) => p.recommended)
              .slice(0, 2)
              .map((product) => (
                <div key={product.id} className="border rounded-lg p-3 bg-yellow-50 border-yellow-200">
                  <div className="aspect-square bg-gray-100 rounded-lg mb-2 flex items-center justify-center">
                    <Package className="w-8 h-8 text-gray-400" />
                  </div>
                  <h4 className="font-medium text-sm mb-1 line-clamp-2">{product.name}</h4>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-green-600">${product.price}</span>
                    <Button size="sm" onClick={() => addToCart(product.id)}>
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* Category Tabs */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-5">
          {categories.map((category) => (
            <TabsTrigger key={category.id} value={category.id} className="text-xs">
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value={selectedCategory} className="space-y-4 mt-4">
          <div className="grid gap-4">
            {filteredProducts.map((product) => (
              <Card key={product.id} className={`${!product.inStock ? "opacity-60" : ""}`}>
                <CardContent className="p-4">
                  <div className="flex space-x-4">
                    <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Package className="w-8 h-8 text-gray-400" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <h3 className="font-semibold text-sm line-clamp-2">{product.name}</h3>
                          <p className="text-xs text-gray-600 mt-1">{product.description}</p>
                        </div>
                        <Button variant="ghost" size="sm" className="ml-2 p-1">
                          <Heart className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="flex items-center space-x-2 mb-2">
                        <div className="flex items-center">
                          <Star className="w-3 h-3 text-yellow-400 fill-current" />
                          <span className="text-xs text-gray-600 ml-1">{product.rating}</span>
                        </div>
                        <span className="text-xs text-gray-500">({product.reviews} reviews)</span>
                        {product.recommended && <Badge className="bg-yellow-500 text-xs">Recommended</Badge>}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-green-600">${product.price}</span>
                          {product.originalPrice && (
                            <span className="text-xs text-gray-500 line-through">${product.originalPrice}</span>
                          )}
                        </div>

                        <div className="flex items-center space-x-2">
                          {cartItems[product.id] ? (
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => removeFromCart(product.id)}
                                className="w-8 h-8 p-0"
                              >
                                <Minus className="w-3 h-3" />
                              </Button>
                              <span className="text-sm font-medium w-8 text-center">{cartItems[product.id]}</span>
                              <Button
                                size="sm"
                                onClick={() => addToCart(product.id)}
                                className="w-8 h-8 p-0"
                                disabled={!product.inStock}
                              >
                                <Plus className="w-3 h-3" />
                              </Button>
                            </div>
                          ) : (
                            <Button size="sm" onClick={() => addToCart(product.id)} disabled={!product.inStock}>
                              {product.inStock ? "Add to Cart" : "Out of Stock"}
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Recent Orders */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Truck className="w-5 h-5 mr-2 text-purple-600" />
            Recent Orders
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-green-800">Order #12345</p>
                <p className="text-sm text-green-600">3 items • Delivered Jan 10</p>
              </div>
            </div>
            <div className="text-right">
              <Badge className="bg-green-500">Delivered</Badge>
              <p className="text-sm text-green-600 mt-1">$67.48</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Truck className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-blue-800">Order #12344</p>
                <p className="text-sm text-blue-600">2 items • Expected Jan 18</p>
              </div>
            </div>
            <div className="text-right">
              <Badge className="bg-blue-500">In Transit</Badge>
              <p className="text-sm text-blue-600 mt-1">$43.99</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Special Offers */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-purple-800">Back to School Sale!</h3>
              <p className="text-sm text-purple-600">Get 20% off on all stationery items</p>
              <p className="text-xs text-purple-500 mt-1">Valid until Jan 31, 2024</p>
            </div>
            <Button className="bg-purple-600 hover:bg-purple-700">Shop Now</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
