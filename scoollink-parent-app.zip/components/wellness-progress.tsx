"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Heart,
  Brain,
  Users,
  Target,
  TrendingUp,
  MessageCircle,
  BookOpen,
  Smile,
  Frown,
  Meh,
  Award,
  Activity,
  Moon,
  Sun,
  Zap,
  Shield,
} from "lucide-react"

export function WellnessProgress() {
  const [selectedMood, setSelectedMood] = useState<string | null>(null)

  const wellnessMetrics = {
    emotional: { score: 85, trend: "up", color: "green" },
    social: { score: 78, trend: "up", color: "blue" },
    academic: { score: 92, trend: "stable", color: "purple" },
    physical: { score: 73, trend: "down", color: "orange" },
    overall: { score: 82, trend: "up", color: "emerald" },
  }

  const moodOptions = [
    { id: "happy", icon: Smile, label: "Happy", color: "text-green-600" },
    { id: "neutral", icon: Meh, label: "Okay", color: "text-yellow-600" },
    { id: "sad", icon: Frown, label: "Sad", color: "text-red-600" },
  ]

  const recentActivities = [
    {
      date: "Today",
      activities: [
        { type: "social", description: "Played with friends during recess", impact: "positive" },
        { type: "academic", description: "Completed math homework independently", impact: "positive" },
        { type: "emotional", description: "Felt anxious about presentation", impact: "concern" },
      ],
    },
    {
      date: "Yesterday",
      activities: [
        { type: "physical", description: "Participated in PE class", impact: "positive" },
        { type: "social", description: "Helped a classmate with project", impact: "positive" },
        { type: "emotional", description: "Showed resilience after mistake", impact: "positive" },
      ],
    },
  ]

  const achievements = [
    { title: "Kindness Champion", description: "Helped 5 classmates this week", icon: Heart, color: "pink" },
    { title: "Focus Master", description: "Completed tasks without reminders", icon: Target, color: "blue" },
    { title: "Brave Speaker", description: "Presented confidently in class", icon: Award, color: "yellow" },
    { title: "Team Player", description: "Great collaboration in group work", icon: Users, color: "green" },
  ]

  const counselorNotes = [
    {
      date: "Jan 12, 2024",
      counselor: "Ms. Sarah Wilson",
      note: "Emma showed great improvement in managing test anxiety. Continue with breathing exercises.",
      priority: "medium",
    },
    {
      date: "Jan 5, 2024",
      counselor: "Ms. Sarah Wilson",
      note: "Excellent social skills development. Emma is becoming more confident in group settings.",
      priority: "low",
    },
  ]

  return (
    <div className="space-y-4 pb-20">
      {/* Wellness Overview */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Emma's Wellness</h2>
              <p className="text-gray-600">Overall wellbeing score</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{wellnessMetrics.overall.score}%</div>
              <div className="flex items-center justify-center mt-1">
                <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                <span className="text-sm text-green-600">Improving</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-lg font-semibold text-blue-600">{wellnessMetrics.emotional.score}%</div>
              <p className="text-xs text-gray-600">Emotional</p>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-purple-600">{wellnessMetrics.social.score}%</div>
              <p className="text-xs text-gray-600">Social</p>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-indigo-600">{wellnessMetrics.academic.score}%</div>
              <p className="text-xs text-gray-600">Academic</p>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-orange-600">{wellnessMetrics.physical.score}%</div>
              <p className="text-xs text-gray-600">Physical</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Mood Check-in */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Heart className="w-5 h-5 mr-2 text-pink-600" />
            Today's Mood Check-in
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-4">How is Emma feeling today?</p>
          <div className="grid grid-cols-3 gap-3 mb-4">
            {moodOptions.map((mood) => {
              const Icon = mood.icon
              return (
                <Button
                  key={mood.id}
                  variant={selectedMood === mood.id ? "default" : "outline"}
                  className={`h-16 flex-col space-y-1 ${selectedMood === mood.id ? "bg-blue-600" : ""}`}
                  onClick={() => setSelectedMood(mood.id)}
                >
                  <Icon className={`w-6 h-6 ${selectedMood === mood.id ? "text-white" : mood.color}`} />
                  <span className="text-sm">{mood.label}</span>
                </Button>
              )
            })}
          </div>
          {selectedMood && <Button className="w-full">Save Mood Entry</Button>}
        </CardContent>
      </Card>

      {/* Wellness Tabs */}
      <Tabs defaultValue="progress" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="progress">Progress</TabsTrigger>
          <TabsTrigger value="activities">Activities</TabsTrigger>
          <TabsTrigger value="achievements">Awards</TabsTrigger>
          <TabsTrigger value="support">Support</TabsTrigger>
        </TabsList>

        <TabsContent value="progress" className="space-y-4">
          {/* Detailed Progress Cards */}
          <div className="grid gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-600" />
                  Emotional Intelligence
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">Self-awareness & regulation</span>
                  <span className="font-semibold">{wellnessMetrics.emotional.score}%</span>
                </div>
                <Progress value={wellnessMetrics.emotional.score} className="h-2 mb-3" />
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Strengths:</p>
                    <p className="text-green-600">• Empathy</p>
                    <p className="text-green-600">• Self-control</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Focus Areas:</p>
                    <p className="text-orange-600">• Anxiety management</p>
                    <p className="text-orange-600">• Confidence building</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center">
                  <Users className="w-5 h-5 mr-2 text-blue-600" />
                  Social Skills
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">Relationships & communication</span>
                  <span className="font-semibold">{wellnessMetrics.social.score}%</span>
                </div>
                <Progress value={wellnessMetrics.social.score} className="h-2 mb-3" />
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Strengths:</p>
                    <p className="text-green-600">• Teamwork</p>
                    <p className="text-green-600">• Helping others</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Focus Areas:</p>
                    <p className="text-orange-600">• Public speaking</p>
                    <p className="text-orange-600">• Conflict resolution</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-orange-600" />
                  Physical Wellness
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">Health & activity levels</span>
                  <span className="font-semibold">{wellnessMetrics.physical.score}%</span>
                </div>
                <Progress value={wellnessMetrics.physical.score} className="h-2 mb-3" />
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="text-center p-2 bg-green-50 rounded">
                    <Sun className="w-4 h-4 text-green-600 mx-auto mb-1" />
                    <p className="text-green-600">7.5h sleep</p>
                  </div>
                  <div className="text-center p-2 bg-blue-50 rounded">
                    <Zap className="w-4 h-4 text-blue-600 mx-auto mb-1" />
                    <p className="text-blue-600">Active</p>
                  </div>
                  <div className="text-center p-2 bg-orange-50 rounded">
                    <Shield className="w-4 h-4 text-orange-600 mx-auto mb-1" />
                    <p className="text-orange-600">Good health</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="activities" className="space-y-4">
          {recentActivities.map((day, index) => (
            <Card key={index}>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">{day.date}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {day.activities.map((activity, actIndex) => (
                  <div
                    key={actIndex}
                    className={`p-3 rounded-lg border ${
                      activity.impact === "positive"
                        ? "bg-green-50 border-green-200"
                        : activity.impact === "concern"
                          ? "bg-yellow-50 border-yellow-200"
                          : "bg-gray-50 border-gray-200"
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      {activity.type === "social" && <Users className="w-4 h-4 text-blue-600 mt-0.5" />}
                      {activity.type === "academic" && <BookOpen className="w-4 h-4 text-purple-600 mt-0.5" />}
                      {activity.type === "emotional" && <Heart className="w-4 h-4 text-pink-600 mt-0.5" />}
                      {activity.type === "physical" && <Activity className="w-4 h-4 text-orange-600 mt-0.5" />}
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.description}</p>
                        <Badge
                          className={`mt-1 text-xs ${
                            activity.impact === "positive"
                              ? "bg-green-500"
                              : activity.impact === "concern"
                                ? "bg-yellow-500"
                                : "bg-gray-500"
                          }`}
                        >
                          {activity.impact === "positive"
                            ? "Positive"
                            : activity.impact === "concern"
                              ? "Needs attention"
                              : "Neutral"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="achievements" className="space-y-4">
          <div className="grid gap-3">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon
              return (
                <Card key={index} className={`border-${achievement.color}-200 bg-${achievement.color}-50`}>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-12 h-12 bg-${achievement.color}-100 rounded-full flex items-center justify-center`}
                      >
                        <Icon className={`w-6 h-6 text-${achievement.color}-600`} />
                      </div>
                      <div className="flex-1">
                        <h3 className={`font-semibold text-${achievement.color}-800`}>{achievement.title}</h3>
                        <p className={`text-sm text-${achievement.color}-600`}>{achievement.description}</p>
                      </div>
                      <Badge className={`bg-${achievement.color}-500`}>New!</Badge>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="support" className="space-y-4">
          {/* Counselor Communication */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center">
                <MessageCircle className="w-5 h-5 mr-2 text-green-600" />
                School Counselor
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <span className="text-green-600 font-semibold text-sm">SW</span>
                  </div>
                  <div>
                    <p className="font-medium text-green-800">Ms. Sarah Wilson</p>
                    <p className="text-sm text-green-600">School Counselor</p>
                  </div>
                </div>
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  <MessageCircle className="w-4 h-4 mr-1" />
                  Chat
                </Button>
              </div>

              {/* Recent Notes */}
              <div className="space-y-3">
                <h4 className="font-medium text-gray-800">Recent Notes</h4>
                {counselorNotes.map((note, index) => (
                  <div
                    key={index}
                    className={`p-3 rounded-lg border ${
                      note.priority === "high"
                        ? "bg-red-50 border-red-200"
                        : note.priority === "medium"
                          ? "bg-yellow-50 border-yellow-200"
                          : "bg-blue-50 border-blue-200"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <p className="text-sm font-medium">{note.counselor}</p>
                      <span className="text-xs text-gray-500">{note.date}</span>
                    </div>
                    <p className="text-sm text-gray-700">{note.note}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Wellness Resources */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Wellness Resources</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                <Brain className="w-4 h-4 mr-2" />
                Mindfulness Exercises for Kids
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Heart className="w-4 h-4 mr-2" />
                Emotional Regulation Techniques
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Users className="w-4 h-4 mr-2" />
                Social Skills Activities
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Moon className="w-4 h-4 mr-2" />
                Better Sleep Habits Guide
              </Button>
            </CardContent>
          </Card>

          {/* Emergency Support */}
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-red-800">Crisis Support</h3>
                  <p className="text-sm text-red-600">24/7 mental health helpline</p>
                </div>
                <Button className="bg-red-600 hover:bg-red-700">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Get Help
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
