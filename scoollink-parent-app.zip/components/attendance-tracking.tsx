"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Calendar, CheckCircle, XCircle, Clock, TrendingUp, FileText, AlertCircle } from "lucide-react"

export function AttendanceTracking() {
  const attendanceData = [
    { date: "2024-01-15", status: "present", checkIn: "8:15 AM", checkOut: "3:30 PM" },
    { date: "2024-01-14", status: "present", checkIn: "8:10 AM", checkOut: "3:25 PM" },
    { date: "2024-01-13", status: "absent", reason: "Sick leave" },
    { date: "2024-01-12", status: "present", checkIn: "8:20 AM", checkOut: "3:35 PM" },
    { date: "2024-01-11", status: "late", checkIn: "8:45 AM", checkOut: "3:30 PM" },
  ]

  const attendancePercentage = 85

  return (
    <div className="space-y-4 pb-20">
      {/* Monthly Overview */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900">January 2024</h2>
              <p className="text-gray-600">Attendance Overview</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{attendancePercentage}%</div>
              <p className="text-sm text-gray-600">Overall</p>
            </div>
          </div>

          <Progress value={attendancePercentage} className="h-3 mb-3" />

          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-semibold text-green-600">18</div>
              <p className="text-xs text-gray-600">Present</p>
            </div>
            <div>
              <div className="text-lg font-semibold text-red-600">2</div>
              <p className="text-xs text-gray-600">Absent</p>
            </div>
            <div>
              <div className="text-lg font-semibold text-yellow-600">1</div>
              <p className="text-xs text-gray-600">Late</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Today's Status */}
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div>
                <h3 className="font-semibold text-green-800">Present Today</h3>
                <p className="text-sm text-green-600">Checked in at 8:15 AM</p>
              </div>
            </div>
            <Badge className="bg-green-500">On Time</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button variant="outline" className="h-16 flex-col space-y-1">
          <FileText className="w-5 h-5" />
          <span className="text-sm">Apply Leave</span>
        </Button>
        <Button variant="outline" className="h-16 flex-col space-y-1">
          <TrendingUp className="w-5 h-5" />
          <span className="text-sm">View Reports</span>
        </Button>
      </div>

      {/* Recent Attendance */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-blue-600" />
            Recent Attendance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {attendanceData.map((record, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                {record.status === "present" && <CheckCircle className="w-5 h-5 text-green-600" />}
                {record.status === "absent" && <XCircle className="w-5 h-5 text-red-600" />}
                {record.status === "late" && <Clock className="w-5 h-5 text-yellow-600" />}

                <div>
                  <p className="font-medium">
                    {new Date(record.date).toLocaleDateString("en-US", {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                  {record.status === "present" && (
                    <p className="text-sm text-gray-600">
                      {record.checkIn} - {record.checkOut}
                    </p>
                  )}
                  {record.status === "absent" && <p className="text-sm text-gray-600">{record.reason}</p>}
                  {record.status === "late" && <p className="text-sm text-gray-600">Late arrival: {record.checkIn}</p>}
                </div>
              </div>

              <Badge
                variant={
                  record.status === "present" ? "default" : record.status === "absent" ? "destructive" : "secondary"
                }
                className={
                  record.status === "present" ? "bg-green-500" : record.status === "late" ? "bg-yellow-500" : ""
                }
              >
                {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Leave Applications */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <FileText className="w-5 h-5 mr-2 text-purple-600" />
            Leave Applications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-yellow-800">Medical Leave Request</p>
                <p className="text-sm text-yellow-600">Jan 20-22, 2024 • Doctor's appointment</p>
                <p className="text-xs text-yellow-500 mt-1">Submitted 2 days ago</p>
              </div>
              <Badge className="bg-yellow-500">Pending</Badge>
            </div>
          </div>

          <div className="p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-start space-x-3">
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-green-800">Family Function</p>
                <p className="text-sm text-green-600">Jan 10, 2024 • Wedding ceremony</p>
                <p className="text-xs text-green-500 mt-1">Approved 1 week ago</p>
              </div>
              <Badge className="bg-green-500">Approved</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Insights */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-indigo-600" />
            Attendance Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <span className="text-sm font-medium text-blue-800">Best Month</span>
              <span className="text-sm text-blue-600">December 2023 (96%)</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <span className="text-sm font-medium text-green-800">Perfect Attendance Days</span>
              <span className="text-sm text-green-600">18 days this month</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
              <span className="text-sm font-medium text-purple-800">Average Check-in Time</span>
              <span className="text-sm text-purple-600">8:12 AM</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
