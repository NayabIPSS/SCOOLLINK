"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { MessageCircle, Send, Phone, Video, Paperclip, Bell, Users, Megaphone } from "lucide-react"

export function CommunicationCenter() {
  const conversations = [
    {
      id: 1,
      name: "Ms. Johnson",
      role: "Math Teacher",
      lastMessage: "Emma did great on her test today!",
      time: "2 hours ago",
      unread: 0,
      avatar: "MJ",
    },
    {
      id: 2,
      name: "School Admin",
      role: "Administration",
      lastMessage: "Parent-teacher meeting scheduled",
      time: "1 day ago",
      unread: 2,
      avatar: "SA",
    },
    {
      id: 3,
      name: "Mr. Davis",
      role: "Science Teacher",
      lastMessage: "Please check Emma's science project",
      time: "2 days ago",
      unread: 1,
      avatar: "MD",
    },
  ]

  const announcements = [
    {
      title: "Winter Break Schedule",
      content: "School will be closed from Dec 25 to Jan 2",
      time: "3 hours ago",
      priority: "high",
    },
    {
      title: "Sports Day Registration",
      content: "Register your child for upcoming sports events",
      time: "1 day ago",
      priority: "medium",
    },
    {
      title: "Library Book Return",
      content: "Please return all borrowed books by Friday",
      time: "2 days ago",
      priority: "low",
    },
  ]

  return (
    <div className="space-y-4 pb-20">
      {/* Quick Actions */}
      <div className="grid grid-cols-3 gap-3">
        <Button variant="outline" className="h-16 flex-col space-y-1">
          <MessageCircle className="w-5 h-5" />
          <span className="text-xs">New Chat</span>
        </Button>
        <Button variant="outline" className="h-16 flex-col space-y-1">
          <Phone className="w-5 h-5" />
          <span className="text-xs">Call School</span>
        </Button>
        <Button variant="outline" className="h-16 flex-col space-y-1">
          <Users className="w-5 h-5" />
          <span className="text-xs">Group Chat</span>
        </Button>
      </div>

      {/* Active Conversations */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <MessageCircle className="w-5 h-5 mr-2 text-blue-600" />
            Messages
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {conversations.map((conversation) => (
            <div
              key={conversation.id}
              className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer"
            >
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-blue-500 text-white">{conversation.avatar}</AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-gray-900 truncate">{conversation.name}</p>
                  <span className="text-xs text-gray-500">{conversation.time}</span>
                </div>
                <p className="text-sm text-gray-600">{conversation.role}</p>
                <p className="text-sm text-gray-500 truncate">{conversation.lastMessage}</p>
              </div>

              {conversation.unread > 0 && (
                <Badge className="bg-red-500 text-white min-w-[20px] h-5 flex items-center justify-center text-xs">
                  {conversation.unread}
                </Badge>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Chat Interface */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-blue-500 text-white text-sm">MJ</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">Ms. Johnson</p>
                <p className="text-sm text-gray-600">Math Teacher</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button size="sm" variant="outline">
                <Phone className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline">
                <Video className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Chat Messages */}
          <div className="space-y-3 max-h-64 overflow-y-auto">
            <div className="flex justify-end">
              <div className="bg-blue-500 text-white p-3 rounded-lg max-w-xs">
                <p className="text-sm">How is Emma doing in math class?</p>
                <p className="text-xs opacity-75 mt-1">10:30 AM</p>
              </div>
            </div>

            <div className="flex justify-start">
              <div className="bg-gray-100 p-3 rounded-lg max-w-xs">
                <p className="text-sm">Emma is doing excellent! She scored 95% on her recent test.</p>
                <p className="text-xs text-gray-500 mt-1">10:45 AM</p>
              </div>
            </div>

            <div className="flex justify-start">
              <div className="bg-gray-100 p-3 rounded-lg max-w-xs">
                <p className="text-sm">She's very engaged in class and asks great questions.</p>
                <p className="text-xs text-gray-500 mt-1">10:46 AM</p>
              </div>
            </div>
          </div>

          {/* Message Input */}
          <div className="flex items-center space-x-2">
            <Button size="sm" variant="outline">
              <Paperclip className="w-4 h-4" />
            </Button>
            <Input placeholder="Type your message..." className="flex-1" />
            <Button size="sm">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Announcements */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center">
            <Megaphone className="w-5 h-5 mr-2 text-orange-600" />
            School Announcements
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {announcements.map((announcement, index) => (
            <div
              key={index}
              className={`p-3 rounded-lg border ${
                announcement.priority === "high"
                  ? "bg-red-50 border-red-200"
                  : announcement.priority === "medium"
                    ? "bg-yellow-50 border-yellow-200"
                    : "bg-blue-50 border-blue-200"
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <p
                      className={`font-medium ${
                        announcement.priority === "high"
                          ? "text-red-800"
                          : announcement.priority === "medium"
                            ? "text-yellow-800"
                            : "text-blue-800"
                      }`}
                    >
                      {announcement.title}
                    </p>
                    <Badge
                      variant="outline"
                      className={`text-xs ${
                        announcement.priority === "high"
                          ? "border-red-300 text-red-600"
                          : announcement.priority === "medium"
                            ? "border-yellow-300 text-yellow-600"
                            : "border-blue-300 text-blue-600"
                      }`}
                    >
                      {announcement.priority}
                    </Badge>
                  </div>
                  <p
                    className={`text-sm ${
                      announcement.priority === "high"
                        ? "text-red-600"
                        : announcement.priority === "medium"
                          ? "text-yellow-600"
                          : "text-blue-600"
                    }`}
                  >
                    {announcement.content}
                  </p>
                  <p
                    className={`text-xs mt-1 ${
                      announcement.priority === "high"
                        ? "text-red-500"
                        : announcement.priority === "medium"
                          ? "text-yellow-500"
                          : "text-blue-500"
                    }`}
                  >
                    {announcement.time}
                  </p>
                </div>
                <Bell
                  className={`w-4 h-4 ${
                    announcement.priority === "high"
                      ? "text-red-500"
                      : announcement.priority === "medium"
                        ? "text-yellow-500"
                        : "text-blue-500"
                  }`}
                />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Emergency Contact */}
      <Card className="border-red-200 bg-red-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-red-800">Emergency Contact</h3>
              <p className="text-sm text-red-600">24/7 school helpline available</p>
            </div>
            <Button className="bg-red-600 hover:bg-red-700">
              <Phone className="w-4 h-4 mr-2" />
              Call Now
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
