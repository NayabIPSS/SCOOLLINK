// Firestore Database Schema for Scoollink

const firestoreSchema = {
  // Core Collections

  students: {
    // Document ID: studentId
    fields: {
      name: "string",
      email: "string",
      class: "string",
      classId: "string",
      grade: "number",
      dateOfBirth: "timestamp",
      parentIds: "array", // Array of parent user IDs
      busId: "string",
      profileImage: "string",
      rfidTag: "string",
      emergencyContacts: "array",
      medicalInfo: "object",
      createdAt: "timestamp",
      updatedAt: "timestamp",
    },
  },

  parents: {
    // Document ID: parentId
    fields: {
      name: "string",
      email: "string",
      phone: "string",
      studentIds: "array", // Array of student IDs
      profileImage: "string",
      preferences: "object",
      createdAt: "timestamp",
      lastLogin: "timestamp",
    },
  },

  attendance: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      date: "string", // YYYY-MM-DD format
      status: "string", // present, absent, late
      checkInTime: "timestamp",
      checkOutTime: "timestamp",
      notes: "string",
      recordedBy: "string",
      createdAt: "timestamp",
    },
  },

  schedules: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      classId: "string",
      date: "string",
      periods: "array", // Array of period objects
      createdAt: "timestamp",
    },
  },

  homework: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      classId: "string",
      subject: "string",
      title: "string",
      description: "string",
      dueDate: "timestamp",
      status: "string", // pending, submitted, graded
      attachments: "array",
      grade: "number",
      feedback: "string",
      createdAt: "timestamp",
      submittedAt: "timestamp",
    },
  },

  // Communication Collections

  messages: {
    // Document ID: auto-generated
    fields: {
      senderId: "string",
      receiverId: "string",
      studentId: "string", // Context student
      content: "string",
      type: "string", // text, image, file
      attachments: "array",
      readAt: "timestamp",
      createdAt: "timestamp",
    },
  },

  announcements: {
    // Document ID: auto-generated
    fields: {
      title: "string",
      content: "string",
      priority: "string", // low, medium, high
      classIds: "array", // Target classes
      createdBy: "string",
      createdAt: "timestamp",
      expiresAt: "timestamp",
    },
  },

  // Tracking Collections

  buses: {
    // Document ID: busId
    fields: {
      number: "string",
      driverId: "string",
      routeId: "string",
      capacity: "number",
      currentLocation: "geopoint",
      status: "string", // active, inactive, maintenance
      lastUpdated: "timestamp",
    },
  },

  drivers: {
    // Document ID: driverId
    fields: {
      name: "string",
      phone: "string",
      license: "string",
      experience: "number",
      busId: "string",
      createdAt: "timestamp",
    },
  },

  routes: {
    // Document ID: routeId
    fields: {
      name: "string",
      stops: "array", // Array of stop objects with locations
      estimatedDuration: "number",
      createdAt: "timestamp",
    },
  },

  rfidScans: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      busId: "string",
      scanType: "string", // boarding, alighting
      location: "geopoint",
      timestamp: "timestamp",
    },
  },

  journeyLogs: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      busId: "string",
      date: "string",
      pickupTime: "timestamp",
      dropoffTime: "timestamp",
      status: "string", // completed, in_progress, cancelled
      createdAt: "timestamp",
    },
  },

  // Wellness Collections

  wellnessMetrics: {
    // Document ID: studentId
    fields: {
      emotional: "object", // { score: number, trend: string }
      social: "object",
      academic: "object",
      physical: "object",
      overall: "object",
      lastUpdated: "timestamp",
    },
    subcollections: {
      history: {
        // Document ID: date (YYYY-MM-DD)
        fields: {
          emotional: "object",
          social: "object",
          academic: "object",
          physical: "object",
          overall: "object",
          date: "string",
          timestamp: "timestamp",
        },
      },
    },
  },

  moodEntries: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      mood: "string", // happy, neutral, sad
      notes: "string",
      triggers: "array",
      date: "string",
      timestamp: "timestamp",
      recordedBy: "string",
    },
  },

  wellnessActivities: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      type: "string",
      description: "string",
      impact: "string", // positive, neutral, concern
      category: "string", // social, academic, emotional, physical
      date: "string",
      timestamp: "timestamp",
      recordedBy: "string",
    },
  },

  achievements: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      title: "string",
      description: "string",
      category: "string",
      icon: "string",
      color: "string",
      dateEarned: "timestamp",
      awardedBy: "string",
    },
  },

  counselorNotes: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      counselorId: "string",
      note: "string",
      priority: "string", // low, medium, high
      recommendations: "array",
      followUpDate: "timestamp",
      date: "string",
      timestamp: "timestamp",
    },
  },

  // Shopping Collections

  products: {
    // Document ID: productId
    fields: {
      name: "string",
      description: "string",
      category: "string", // books, uniforms, stationery, electronics
      price: "number",
      originalPrice: "number",
      images: "array",
      inStock: "boolean",
      stockQuantity: "number",
      rating: "number",
      reviewCount: "number",
      recommended: "boolean",
      classIds: "array", // Recommended for specific classes
      createdAt: "timestamp",
    },
  },

  orders: {
    // Document ID: orderId
    fields: {
      parentId: "string",
      studentId: "string",
      items: "array", // Array of order items
      totalAmount: "number",
      status: "string", // pending, confirmed, shipped, delivered, cancelled
      paymentStatus: "string",
      paymentMethod: "string",
      shippingAddress: "object",
      trackingNumber: "string",
      createdAt: "timestamp",
      updatedAt: "timestamp",
    },
  },

  // Fee Management Collections

  feeStructure: {
    // Document ID: classId
    fields: {
      class: "string",
      fees: "array", // Array of fee objects
      totalAmount: "number",
      dueDate: "timestamp",
      academicYear: "string",
    },
  },

  payments: {
    // Document ID: paymentId
    fields: {
      studentId: "string",
      parentId: "string",
      amount: "number",
      feeType: "string",
      paymentMethod: "string",
      transactionId: "string",
      status: "string", // pending, completed, failed
      receiptUrl: "string",
      createdAt: "timestamp",
    },
  },

  // AI and Analytics Collections

  chatHistory: {
    // Document ID: auto-generated
    fields: {
      parentId: "string",
      studentId: "string",
      userMessage: "string",
      aiResponse: "string",
      context: "string",
      timestamp: "timestamp",
    },
  },

  predictions: {
    // Document ID: auto-generated
    fields: {
      studentId: "string",
      type: "string", // performance, wellness, behavior
      prediction: "object",
      recommendations: "array",
      confidence: "number",
      timestamp: "timestamp",
    },
  },

  notifications: {
    // Document ID: auto-generated
    fields: {
      parentId: "string",
      studentId: "string",
      type: "string",
      title: "string",
      message: "string",
      data: "object",
      priority: "string",
      read: "boolean",
      timestamp: "timestamp",
    },
  },
}

// Firestore Security Rules
const securityRules = `
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Parents can only access their own data and their children's data
    match /parents/{parentId} {
      allow read, write: if request.auth != null && request.auth.uid == parentId;
    }
    
    match /students/{studentId} {
      allow read, write: if request.auth != null && 
        request.auth.uid in resource.data.parentIds;
    }
    
    // Attendance records - parents can read their children's records
    match /attendance/{attendanceId} {
      allow read: if request.auth != null && 
        request.auth.uid in get(/databases/$(database)/documents/students/$(resource.data.studentId)).data.parentIds;
      allow write: if request.auth != null && 
        request.auth.token.role in ['teacher', 'admin'];
    }
    
    // Wellness data - parents can read, counselors can write
    match /wellnessMetrics/{studentId} {
      allow read: if request.auth != null && 
        request.auth.uid in get(/databases/$(database)/documents/students/$(studentId)).data.parentIds;
      allow write: if request.auth != null && 
        request.auth.token.role in ['counselor', 'teacher', 'admin'];
    }
    
    // Messages - users can read/write their own messages
    match /messages/{messageId} {
      allow read, write: if request.auth != null && 
        (request.auth.uid == resource.data.senderId || 
         request.auth.uid == resource.data.receiverId);
    }
    
    // Orders - parents can manage their own orders
    match /orders/{orderId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.parentId;
    }
    
    // Public read access for products and announcements
    match /products/{productId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        request.auth.token.role in ['admin'];
    }
    
    match /announcements/{announcementId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        request.auth.token.role in ['teacher', 'admin'];
    }
  }
}
`

module.exports = { firestoreSchema, securityRules }
