"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { BottomNavigation } from "@/components/bottom-navigation"
import { HomeDashboard } from "@/components/home-dashboard"
import { LiveTracking } from "@/components/live-tracking"
import { AttendanceTracking } from "@/components/attendance-tracking"
import { CommunicationCenter } from "@/components/communication-center"
import { SchoolShopping } from "@/components/school-shopping"
import { WellnessProgress } from "@/components/wellness-progress"

export default function ScoolinkApp() {
  const [activeTab, setActiveTab] = useState("home")

  const getHeaderTitle = () => {
    switch (activeTab) {
      case "home":
        return "Good Morning!"
      case "tracking":
        return "Live Tracking"
      case "schedule":
        return "Attendance"
      case "chat":
        return "Messages"
      case "shopping":
        return "School Store"
      case "wellness":
        return "Wellness & Progress"
      case "profile":
        return "Profile"
      default:
        return "Scoollink"
    }
  }

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return <HomeDashboard />
      case "tracking":
        return <LiveTracking />
      case "schedule":
        return <AttendanceTracking />
      case "chat":
        return <CommunicationCenter />
      case "shopping":
        return <SchoolShopping />
      case "wellness":
        return <WellnessProgress />
      case "profile":
        return (
          <div className="p-4 pb-20">
            <div className="text-center py-20">
              <h2 className="text-xl font-semibold text-gray-600">Profile Section</h2>
              <p className="text-gray-500 mt-2">Coming soon...</p>
            </div>
          </div>
        )
      default:
        return <HomeDashboard />
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <Header title={getHeaderTitle()} showSearch={activeTab === "chat"} />

      <main className="p-4">{renderContent()}</main>

      <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}
