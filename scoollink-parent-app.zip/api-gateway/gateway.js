const express = require("express")
const { createProxyMiddleware } = require("http-proxy-middleware")
const rateLimit = require("express-rate-limit")
const helmet = require("helmet")
const cors = require("cors")

const app = express()

// Security middleware
app.use(helmet())
app.use(
  cors({
    origin: process.env.ALLOWED_ORIGINS?.split(",") || ["http://localhost:3000"],
    credentials: true,
  }),
)

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: "Too many requests from this IP",
})
app.use(limiter)

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.sendStatus(401)
  }

  // Verify JWT token (implement your JWT verification logic)
  // For now, we'll simulate token verification
  req.user = { id: "parent_123", role: "parent" }
  next()
}

// Core Backend Services Proxy
app.use(
  "/api/auth",
  createProxyMiddleware({
    target: process.env.AUTH_SERVICE_URL || "http://localhost:3001",
    changeOrigin: true,
    pathRewrite: { "^/api/auth": "" },
  }),
)

app.use(
  "/api/students",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.STUDENT_SERVICE_URL || "http://localhost:3002",
    changeOrigin: true,
    pathRewrite: { "^/api/students": "" },
  }),
)

app.use(
  "/api/tracking",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.TRACKING_SERVICE_URL || "http://localhost:3003",
    changeOrigin: true,
    pathRewrite: { "^/api/tracking": "" },
  }),
)

app.use(
  "/api/communication",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.COMMUNICATION_SERVICE_URL || "http://localhost:3004",
    changeOrigin: true,
    pathRewrite: { "^/api/communication": "" },
  }),
)

app.use(
  "/api/shopping",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.SHOPPING_SERVICE_URL || "http://localhost:3005",
    changeOrigin: true,
    pathRewrite: { "^/api/shopping": "" },
  }),
)

app.use(
  "/api/wellness",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.WELLNESS_SERVICE_URL || "http://localhost:3006",
    changeOrigin: true,
    pathRewrite: { "^/api/wellness": "" },
  }),
)

// AI Microservices Proxy
app.use(
  "/api/ai/chat",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.AI_CHAT_SERVICE_URL || "http://localhost:4001",
    changeOrigin: true,
    pathRewrite: { "^/api/ai/chat": "" },
  }),
)

app.use(
  "/api/ai/predictions",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.AI_PREDICTION_SERVICE_URL || "http://localhost:4002",
    changeOrigin: true,
    pathRewrite: { "^/api/ai/predictions": "" },
  }),
)

app.use(
  "/api/ai/ocr",
  authenticateToken,
  createProxyMiddleware({
    target: process.env.AI_OCR_SERVICE_URL || "http://localhost:4003",
    changeOrigin: true,
    pathRewrite: { "^/api/ai/ocr": "" },
  }),
)

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "OK", timestamp: new Date().toISOString() })
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`API Gateway running on port ${PORT}`)
})
